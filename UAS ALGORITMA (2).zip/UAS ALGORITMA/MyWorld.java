import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{
    SimpleTimer tim = new SimpleTimer();
    Counter timeCount = new Counter();
    int start = 0;
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        prepare();
    }
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        bee bee = new bee();
        addObject(bee,219,206);
        addObject(timeCount, 100, 250);
        timeCount.setValue(30);
        showText("Rofi Nafiis Z", 100, 30);
    }
    public void act(){
        if (start == 1){
            if (tim.millisElapsed() > 1000)
            {
                timeCount.add(-1);
                tim.mark();
            }
        }
        if(Greenfoot.isKeyDown("q"))
        {
            start = 1;
            tim.mark();
            
        }
    }
}
